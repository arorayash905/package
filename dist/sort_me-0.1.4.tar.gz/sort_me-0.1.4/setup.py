from setuptools import setup

setup(name='sort_me',
      version='0.1.4',
      description='Sorting Algorithms',
      packages=['sort_me'],
      author='Yash Arora',
      author_email='arorayash905@gmail.com',
      zip_safe=False)